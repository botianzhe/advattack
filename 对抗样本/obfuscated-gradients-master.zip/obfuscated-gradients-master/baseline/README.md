# Baseline resnet model (unsecured)

## Setup

Run `./setup.sh` to fetch models.

## Breaks

* Standard PGD
