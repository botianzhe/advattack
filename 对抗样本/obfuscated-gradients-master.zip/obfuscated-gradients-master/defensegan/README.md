# Defense-GAN: Protecting Classifiers Against Adversarial Attacks Using Generative Models

Paper: [Samangouei et al. 2018](https://openreview.net/pdf?id=BkJ3ibb0-)

## Setup

Run `./setup.sh` to fetch models.

## Partial Breaks

* Theoretical Break: Reparamterization
* Emperical Partial Break: BPDA
