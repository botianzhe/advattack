# Characterizing Adversarial Subspaces Using Local Intrinsic Dimensionality

Paper: [Ma et al. 2018](https://arxiv.org/abs/1801.02613)

## Setup

Run `./setup.sh` to fetch models.

## Breaks

* Detection: PGD with high confidence
